"""Render package for status output."""

from village.render.json import render_status_json

__all__ = ["render_status_json"]
