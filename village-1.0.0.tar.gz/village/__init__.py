"""Village - CLI-native parallel development orchestrator."""
